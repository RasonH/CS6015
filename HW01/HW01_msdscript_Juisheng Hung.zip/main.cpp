//
//  main.cpp
//  CommandLine
//
//  Created by Rason Hung on 1/16/23.
//

#include <iostream>
#include "cmdline.h"

int main(int argc, const char * argv[]) {
    use_arguments(argc, argv);
    return 0;
}
