//
//  main.cpp
//  CommandLine
//
//  Created by Rason Hung on 1/16/23.
//

//#define CATCH_CONFIG_MAIN
#include <iostream>
#include "cmdline.h"
#include "expr.h"

int main(int argc, const char * argv[]) {
    use_arguments(argc, argv);
    return 0;
}
